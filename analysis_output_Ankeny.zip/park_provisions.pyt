# -*- coding: utf-8 -*-
# =============================================================================
# Author:   Muhammad Usama Aslam (usama98@iastate.edu), Iowa State University
# Date:     11/25/2026 (last modified)
# Version:  Python 3 with arcpy (ArcGIS Pro); tested with Python 3.11.11 in
#           ArcGIS Pro 3.5.3. arcpy only comes with ArcGIS Pro, so use the
#           toolbox in ArcGIS Pro or run it with ArcGIS Pro's Python (propy.bat)
# Purpose:  Python toolbox version of park_provisions_progressor.py (open space
#           distribution analysis), extended to work for any Iowa city instead
#           of only Ames. Parks now come from the statewide OpenStreetMap POI
#           polygons (fclass = 'park') and are clipped to the city buffer like
#           the other statewide data. For every 2010 census block in the city:
#             BLK_ACCESS    block area (sq m) within the access distance of
#                           each open space, summed over all open spaces
#             ACC_FRAC      BLK_ACCESS / block area (area-weighted number of
#                           open spaces within the access distance)
#             SUM_INV_DIST  sum of (access distance - distance) to each open
#                           space within the access distance (closer = higher);
#                           stored as SUM_INV_DI in the shapefile output
#           The city is a tool parameter, not hard coded; its default comes
#           from the DEFAULT_CITY variable below (Ankeny).
# =============================================================================

import os
import subprocess
import sys


def run_directly():
    """True only when Python was started with this file (python park_provisions.pyt).
    ArcGIS also loads a toolbox with __name__ == "__main__", so that test is not enough."""
    script = sys.argv[0] if getattr(sys, "argv", None) else ""
    if __name__ != "__main__" or not script:
        return False
    return (os.path.normcase(os.path.abspath(script))
            == os.path.normcase(os.path.abspath(__file__)))


try:
    import arcpy
except ModuleNotFoundError:
    # arcpy is only installed in the Python that comes with ArcGIS Pro. When this file is
    # run with another Python (for example an Anaconda environment) it would stop with
    # "No module named 'arcpy'", so start it again with ArcGIS Pro's Python instead.
    if not run_directly():
        raise
    propy = os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"),
                         "ArcGIS", "Pro", "bin", "Python", "Scripts", "propy.bat")
    if os.path.isfile(propy) and not os.environ.get("PARK_PROVISIONS_PROPY"):
        print("arcpy is not installed in this Python; running again with ArcGIS Pro's Python...",
              flush=True)
        # the environment variable stops this from repeating if arcpy is still missing
        sys.exit(subprocess.call([propy, os.path.abspath(__file__)] + sys.argv[1:],
                                 env=dict(os.environ, PARK_PROVISIONS_PROPY="1")))
    sys.exit("arcpy was not found. Open this toolbox in ArcGIS Pro, or run it with "
             "ArcGIS Pro's Python: propy.bat park_provisions.pyt")

# field in the incorporated cities data that holds the city name
CITY_FIELD = "NAME10"

# default values of the tool parameters; change them here or in the tool dialog
DEFAULT_CITY = "Ankeny"                 # city to analyze (a variable, not hard coded)
DEFAULT_PARK_SQL = "fclass = 'park'"    # picks the parks out of the OSM POIs
DEFAULT_ACCESS_M = 1500                 # access distance in meters


class msgStub:
    """Stands in for the tool's messages object when run outside a tool dialog."""
    def addMessage(self, text):
        arcpy.AddMessage(text)

    def addWarningMessage(self, text):
        arcpy.AddWarning(text)

    def addErrorMessage(self, text):
        arcpy.AddError(text)


class Toolbox(object):
    def __init__(self):
        """Define the toolbox (the name of the toolbox is the name of the .pyt file)."""
        self.label = "Park Provisions"
        self.alias = "parkprovisions"

        # List of tool classes associated with this toolbox
        self.tools = [OpenSpaceAccess]


class OpenSpaceAccess(object):
    def __init__(self):
        """Define the tool (tool name is the name of the class)."""
        self.label = "Open Space Access by Census Block"
        self.description = ("Measures access to parks and public open space for every 2010 "
                            "census block in a chosen Iowa city, using OpenStreetMap parks and "
                            "public conservation and recreation lands.")
        self.canRunInBackground = False

    def getParameterInfo(self):
        """Define parameter definitions"""
        # 0 - city to analyze (a parameter, so any city can be run later)
        city = arcpy.Parameter(
            name="city_name",
            displayName="City Name",
            datatype="GPString",
            parameterType="Required",
            direction="Input")
        city.value = DEFAULT_CITY

        # 1 - statewide incorporated city boundaries
        cities = arcpy.Parameter(
            name="cities",
            displayName="Incorporated Cities (incorporated_cities_2010)",
            datatype="DEFeatureClass",
            parameterType="Required",
            direction="Input")
        cities.filter.list = ["Polygon"]

        # 2 - statewide OSM points of interest (polygons)
        osm_pois = arcpy.Parameter(
            name="osm_pois",
            displayName="Statewide OSM POI Polygons (gis_osm_pois_a_free_1)",
            datatype="DEFeatureClass",
            parameterType="Required",
            direction="Input")
        osm_pois.filter.list = ["Polygon"]

        # 3 - expression that pulls the parks out of the POIs
        park_sql = arcpy.Parameter(
            name="park_sql",
            displayName="Expression to Select Parks from the OSM POIs",
            datatype="GPSQLExpression",
            parameterType="Required",
            direction="Input")
        park_sql.parameterDependencies = [osm_pois.name]
        park_sql.value = DEFAULT_PARK_SQL

        # 4 - public conservation and recreation lands
        cons_rec = arcpy.Parameter(
            name="cons_rec_lands",
            displayName="Public Conservation and Recreation Lands (cons_rec_lands_public)",
            datatype="DEFeatureClass",
            parameterType="Required",
            direction="Input")
        cons_rec.filter.list = ["Polygon"]

        # 5 - statewide 2010 census blocks
        blocks = arcpy.Parameter(
            name="census_blocks",
            displayName="2010 Census Blocks (census_2010_blocks)",
            datatype="DEFeatureClass",
            parameterType="Required",
            direction="Input")
        blocks.filter.list = ["Polygon"]

        # 6 - access distance used for the city buffer, open space buffers and near table
        access_m = arcpy.Parameter(
            name="access_distance",
            displayName="Access Distance (meters)",
            datatype="GPDouble",
            parameterType="Required",
            direction="Input")
        access_m.value = DEFAULT_ACCESS_M

        # 7 - output shapefile
        out_fc = arcpy.Parameter(
            name="out_features",
            displayName="Output Feature Class (e.g. analysis_output_Ankeny.shp)",
            datatype="DEFeatureClass",
            parameterType="Required",
            direction="Output")

        params = [city, cities, osm_pois, park_sql, cons_rec, blocks, access_m, out_fc]
        return params

    def isLicensed(self):
        """Set whether tool is licensed to execute."""
        return True

    def updateParameters(self, parameters):
        """Fill the City Name drop-down from the cities data to avoid typos."""
        city, cities = parameters[0], parameters[1]
        if cities.value:
            try:
                with arcpy.da.SearchCursor(cities.valueAsText, [CITY_FIELD]) as cur:
                    city.filter.list = sorted({row[0] for row in cur if row[0]})
            except Exception:
                # no NAME10 field: allow any typed name
                city.filter.list = []
        return

    def updateMessages(self, parameters):
        """Check the access distance before the tool runs."""
        access_m = parameters[6]
        if access_m.value is not None and access_m.value <= 0:
            access_m.setErrorMessage("Access distance must be greater than 0 meters.")
        return

    def execute(self, parameters, messages):
        """Run the analysis with the values from the tool dialog."""
        p = parameters
        park_provisions(p[0].valueAsText, p[1].valueAsText, p[2].valueAsText,
                        p[3].valueAsText, p[4].valueAsText, p[5].valueAsText,
                        float(p[6].value), p[7].valueAsText, messages)
        return

    def postExecute(self, parameters):
        """This method takes place after outputs are processed and
        added to the display."""
        return


##----------------------------------------------------------------------
## Analysis

def count(data):
    """Number of rows in a feature class or table."""
    return int(arcpy.management.GetCount(data)[0])


def park_provisions(city_name, cities, osm_pois, park_sql, cons_rec, census_blocks,
                    access_m, out_fc, messages):
    """Open space access for every census block in one city."""
    messages.addMessage(f"City: {city_name}\nAccess distance: {access_m} m\nOutput: {out_fc}")
    arcpy.env.overwriteOutput = True

    # work in the census blocks' projected coordinate system (UTM 15N, meters)
    block_sr = arcpy.Describe(census_blocks).spatialReference
    if block_sr.type != "Projected":
        raise ValueError("Census blocks must be in a projected coordinate system.")
    arcpy.env.outputCoordinateSystem = block_sr

    # name the datum transformation for inputs whose datum differs from the blocks' (the OSM
    # parks are WGS84, the other data NAD83). Otherwise ArcGIS Pro uses the transformations
    # of the open map, or none without a map, and the results change slightly between runs
    transformations = []
    for fc in (cities, osm_pois, cons_rec):
        desc = arcpy.Describe(fc)
        if desc.spatialReference.GCS.name != block_sr.GCS.name:
            best = arcpy.ListTransformations(desc.spatialReference, block_sr, desc.extent)[:1]
            transformations += [t for t in best if t not in transformations]
    if transformations:
        arcpy.env.geographicTransformations = ";".join(transformations)
        messages.addMessage("Datum transformation: " + "; ".join(transformations))

    dist = f"{access_m} Meters"        # linear unit text for the tools
    to_m = block_sr.metersPerUnit      # converts NEAR_DIST to meters

    # intermediate data is kept in memory
    city_fc = r"memory\city"
    city_buf = r"memory\city_buffer"
    parks_state = r"memory\osm_parks"
    parks_city = r"memory\osm_parks_clip"
    cons_city = r"memory\cons_rec_clip"
    open_space = r"memory\open_space"
    os_buffer = r"memory\open_space_buffer"
    blocks = r"memory\census_blocks_clip"
    near_tbl = r"memory\near_table"
    near_sum = r"memory\near_table_sum"
    temp = [city_fc, city_buf, parks_state, parks_city, cons_city,
            open_space, os_buffer, blocks, near_tbl, near_sum]

    try:
        # 1. select the city of interest (name comes from the parameter, not hard coded)
        arcpy.SetProgressorLabel(f"Selecting {city_name}...")
        where = "{} = '{}'".format(arcpy.AddFieldDelimiters(cities, CITY_FIELD),
                                   city_name.replace("'", "''"))
        arcpy.analysis.Select(cities, city_fc, where)
        n_city = count(city_fc)
        if n_city != 1:
            raise ValueError(f"{n_city} cities match {where}; expected 1. Check the city name.")

        # 2. buffer the city so open space just outside the boundary still counts
        arcpy.SetProgressorLabel("Buffering the city boundary...")
        arcpy.analysis.Buffer(city_fc, city_buf, dist, dissolve_option="ALL")

        # 3. NEW: extract only the parks from the statewide OSM POIs (Select tool)
        arcpy.SetProgressorLabel("Selecting parks from the OSM POIs...")
        arcpy.analysis.Select(osm_pois, parks_state, park_sql)

        # 4. NEW: clip the parks to the city buffer, like the other statewide data
        arcpy.analysis.Clip(parks_state, city_buf, parks_city)
        messages.addMessage(f"OSM parks statewide: {count(parks_state)}; "
                            f"within the city buffer: {count(parks_city)}")

        # 5. clip the public conservation and recreation lands to the city buffer
        arcpy.SetProgressorLabel("Clipping public lands to the city buffer...")
        arcpy.analysis.Clip(cons_rec, city_buf, cons_city)

        # 6. combine parks and public lands into one open space layer
        arcpy.management.Merge([parks_city, cons_city], open_space)
        messages.addMessage(f"Public lands within the city buffer: {count(cons_city)}; "
                            f"total open spaces: {count(open_space)}")

        # 7. clip the statewide census blocks to the city boundary
        arcpy.SetProgressorLabel("Clipping census blocks to the city...")
        arcpy.analysis.Clip(census_blocks, city_fc, blocks)
        n_blk = count(blocks)
        messages.addMessage(f"Census blocks in {city_name}: {n_blk}")

        # 8. near table: distance from each block to every open space within the access distance
        arcpy.SetProgressorLabel("Generating the near table...")
        arcpy.analysis.GenerateNearTable(blocks, open_space, near_tbl, search_radius=dist,
                                         location="NO_LOCATION", angle="NO_ANGLE",
                                         closest="ALL", closest_count=0, method="PLANAR")

        # 9. inverted distance: access distance minus near distance (closer = larger)
        arcpy.management.AddField(near_tbl, "INV_DIST", "DOUBLE")
        arcpy.management.CalculateField(near_tbl, "INV_DIST",
                                        f"{access_m} - !NEAR_DIST! * {to_m}", "PYTHON3")

        # 10. sum the inverted distances for each block (IN_FID = block OBJECTID)
        arcpy.analysis.Statistics(near_tbl, near_sum, [["INV_DIST", "SUM"]], "IN_FID")

        # 11. add the access fields and join SUM_INV_DIST back to the blocks
        arcpy.management.AddField(blocks, "BLK_ACCESS", "DOUBLE")
        arcpy.management.AddField(blocks, "ACC_FRAC", "DOUBLE")
        oid = arcpy.Describe(blocks).OIDFieldName
        arcpy.management.JoinField(blocks, oid, near_sum, "IN_FID", ["SUM_INV_DIST"])

        # 12. buffer each open space by the access distance (no dissolve, each one counts)
        arcpy.SetProgressorLabel("Buffering open spaces...")
        arcpy.analysis.Buffer(open_space, os_buffer, dist, dissolve_option="NONE")

        # read the buffers once, keeping each extent for a quick overlap check
        buffers = []
        with arcpy.da.SearchCursor(os_buffer, ["SHAPE@"]) as cur:
            for (shape,) in cur:
                e = shape.extent
                buffers.append((shape, e.XMin, e.YMin, e.XMax, e.YMax))

        # 13. block access: block area inside each open space buffer (step progressor)
        arcpy.SetProgressor("step", f"Measuring open space access for {n_blk} blocks...",
                            0, max(n_blk, 1), 1)
        access = {}
        with arcpy.da.SearchCursor(blocks, ["OID@", "SHAPE@"]) as cur:
            for blk_id, shape in cur:
                e = shape.extent
                blk_access = 0.0
                for buf, xmin, ymin, xmax, ymax in buffers:
                    # skip buffers whose extent does not reach the block
                    if xmin > e.XMax or xmax < e.XMin or ymin > e.YMax or ymax < e.YMin:
                        continue
                    blk_access += shape.intersect(buf, 4).area
                area = shape.area
                access[blk_id] = (blk_access, blk_access / area if area > 0 else 0.0)
                arcpy.SetProgressorPosition()
        arcpy.ResetProgressor()

        # 14. write BLK_ACCESS and ACC_FRAC; blocks with no open space in range get 0
        with arcpy.da.UpdateCursor(blocks, ["OID@", "BLK_ACCESS", "ACC_FRAC", "SUM_INV_DIST"]) as cur:
            for row in cur:
                row[1], row[2] = access.get(row[0], (0.0, 0.0))
                if row[3] is None:
                    row[3] = 0.0
                cur.updateRow(row)

        n_zero = sum(1 for a, f in access.values() if a == 0)
        mean_frac = sum(f for a, f in access.values()) / len(access) if access else 0.0
        messages.addMessage(f"Blocks with no open space within {access_m} m: {n_zero}; "
                            f"mean ACC_FRAC: {mean_frac:.2f}")

        # 15. save the result as a shapefile
        arcpy.SetProgressorLabel("Saving the output...")
        arcpy.management.CopyFeatures(blocks, out_fc)
        messages.addMessage(f"Saved: {out_fc}")

    finally:
        # 16. remove the intermediate data from memory
        for t in temp:
            try:
                if arcpy.Exists(t):
                    arcpy.management.Delete(t)
            except Exception:
                pass
        arcpy.ResetProgressor()


##----------------------------------------------------------------------
## Stand-alone use (outside the ArcGIS Pro tool dialog), for example:
## propy park_provisions.pyt
##     no arguments: runs DEFAULT_CITY with the class data stored beside this toolbox
## propy park_provisions.pyt Ankeny cities.shp pois.shp "fclass = 'park'" cons.shp blocks.shp 1500 out.shp
##     the 8 tool parameters, in the same order as in the tool dialog

if run_directly():
    if len(sys.argv) == 1:
        # no arguments: default city, data folders as unzipped beside this toolbox, and
        # the output saved in its own folder (analysis_output_Ankeny for Ankeny)
        here = os.path.dirname(os.path.abspath(__file__))
        data = os.path.join(here, "data", "data")
        out_name = "analysis_output_" + DEFAULT_CITY.replace(" ", "_")
        os.makedirs(os.path.join(here, out_name), exist_ok=True)
        sys.argv += [DEFAULT_CITY,
                     os.path.join(data, "incorporated_cities_2010.shp"),
                     os.path.join(here, "Assignment_5", "Assignment_5", "gis_osm_pois_a_free_1.shp"),
                     DEFAULT_PARK_SQL,
                     os.path.join(data, "cons_rec_lands_public.shp"),
                     os.path.join(data, "census_2010_blocks.shp"),
                     str(DEFAULT_ACCESS_M),
                     os.path.join(here, out_name, out_name + ".shp")]
    if len(sys.argv) != 9:
        sys.exit("Expected 8 arguments: city cities osm_pois park_sql cons_rec census_blocks "
                 "access_distance_m out_features")
    a = sys.argv[1:]
    park_provisions(a[0], a[1], a[2], a[3], a[4], a[5], float(a[6]), a[7], msgStub())
